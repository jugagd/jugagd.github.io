import React, { Component } from 'react';
import logo from './logo.svg';
import './App.css';
import Coursesales from './Coursesales';

class App extends Component {
  render() {
    var courses=[
      {name:'Complete iOS dev course', price: 199},
      {name:'Complete FE dev course', price: 299},
      {name:'Complete Unity course', price: 59},
      {name:'Complete Game Design course', price: 163}
    ];
    return (
      <div className="App">
        <h2>Welcome to Course Purchase Page</h2>
        <Coursesales items={courses}/>
      </div>
    );
  }
}

export default App;
